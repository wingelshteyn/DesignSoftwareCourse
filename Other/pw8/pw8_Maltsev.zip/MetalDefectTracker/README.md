# MetalDefectTracker

Сервисно-ориентированная реструктуризация оригинального проекта MetalDefectTracker.

## Структура репозитория

- `frontend/` - React фронтенд
- `gateway/` - конфигурация API-шлюза Nginx
- `services/` - бизнес-сервисы (`auth_accounts`, `administration`, `receiver`, `control`, `analytics`, `ml_service`)
- `shared-contracts/` - общие DTO и контракты
- `infra/` - конфигурация поддерживающей инфраструктуры (`postgres`, `rabbitmq`, `redis`, `minio`)
