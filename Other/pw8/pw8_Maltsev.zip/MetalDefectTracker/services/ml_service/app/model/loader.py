"""
for loading and holding the ML model artefact
"""


class ModelLoader:

    def __init__(self) -> None:
        self.loaded = False

    def load(self):
        self.loaded = True
        return {"status": "loaded"}

    def unload(self) -> None:
        self.loaded = False


model_loader = ModelLoader()
