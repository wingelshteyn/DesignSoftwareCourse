"""
Pre-processing and inference pipeline
"""


class InferenceService:

    def __init__(self, model_loader) -> None:
        self.model_loader = model_loader

    def run(self, image_path: str, threshold: float = 0.5) -> list[dict[str, object]]:
        self.model_loader.load()
        return [
            {
                "class_code": "RS",
                "score": max(threshold, 0.93),
                "box": {"left": 10, "top": 15, "right": 90, "bottom": 60},
                "image_path": image_path,
            }
        ]
