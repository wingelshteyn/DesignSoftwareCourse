"""
FastAPI application entry point for ML Inference Service.
"""

from fastapi import FastAPI
from pydantic import BaseModel

from .config import settings
from .model.inference import InferenceService
from .model.loader import model_loader


app = FastAPI()

_inference_service = InferenceService(model_loader)


class DetectionRequest(BaseModel):
    image_path: str
    threshold: float = 0.5


@app.get("/health")
async def health_check():
    return {"service": "ml_service", "status": "ok", "model": settings.model_name}


@app.post("/detect")
async def detect_defects(request: DetectionRequest):
    predictions = _inference_service.run(request.image_path, request.threshold)
    return {"predictions": predictions}
