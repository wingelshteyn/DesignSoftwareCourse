from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # Service metadata
    service_name: str = "ml_service"
    model_name: str = "detector-v1"


settings = Settings()
