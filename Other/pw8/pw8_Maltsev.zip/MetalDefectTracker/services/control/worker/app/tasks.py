from worker.app.celery_app import celery_app
from worker.service.orchestrator import ControlProcessingOrchestrator


@celery_app.task(name="control_worker.process_detection")
def process_detection_task(control_record_id: int, image_path: str, threshold: float) -> dict[str, object]:
    orchestrator = ControlProcessingOrchestrator()
    return orchestrator.process(control_record_id=control_record_id, image_path=image_path, threshold=threshold)
