from celery import Celery


celery_app = Celery("control_worker")
celery_app.conf.broker_url = "amqp://mdt:mdt_secret@rabbitmq:5672//"
celery_app.conf.result_backend = None
