import sys
from pathlib import Path

SHARED_CONTRACTS_ROOT = Path(__file__).resolve().parents[4] / "shared-contracts" / "python"
if str(SHARED_CONTRACTS_ROOT) not in sys.path:
    sys.path.append(str(SHARED_CONTRACTS_ROOT))

from mdt_shared_contracts.contracts import DetectionTask


class ControlProcessingOrchestrator:
    """
    Lightweight orchestration layer for the Control worker.
    A real implementation would pull the image from MinIO, call the ML service,
    and persist detection results back to PostgreSQL.
    """

    def process(self, control_record_id: int, image_path: str, threshold: float) -> dict[str, object]:
        task = DetectionTask(
            control_record_id=control_record_id,
            image_path=image_path,
            threshold=threshold,
        )
        return {
            "status": "processed",
            "control_record_id": task.control_record_id,
            "image_path": task.image_path,
            "threshold": task.threshold,
        }
