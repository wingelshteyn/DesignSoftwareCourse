class ControlRecordRepository:
    """
    Placeholder repository for control records, detections, and verification results.
    """

    def get_record(self, control_record_id: int) -> dict[str, object]:
        return {"control_record_id": control_record_id}
