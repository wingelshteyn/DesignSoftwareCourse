from django.http import JsonResponse


def health(request):
    return JsonResponse({"service": "control", "status": "ok"})
