from dataclasses import dataclass
import sys
from pathlib import Path

SHARED_CONTRACTS_ROOT = Path(__file__).resolve().parents[3] / "shared-contracts" / "python"
if str(SHARED_CONTRACTS_ROOT) not in sys.path:
    sys.path.append(str(SHARED_CONTRACTS_ROOT))

from mdt_shared_contracts.contracts import ProcessingConfiguration, VerificationAvailability

from .workflows import DetectionWorkflow


@dataclass(slots=True)
class VerificationWorkflow:
    """
    Verification depends on access decisions already performed at the
    service boundary and on processing configuration supplied by the
    Administration service.
    """

    processing_configuration: ProcessingConfiguration
    detection_workflow: DetectionWorkflow

    def can_start_verification(self, role: str) -> VerificationAvailability:
        if not self.processing_configuration.manual_verification_enabled:
            return VerificationAvailability(False, "Manual verification disabled.")
        if role not in {"operator", "administrator"}:
            return VerificationAvailability(False, "Role cannot verify results.")
        return VerificationAvailability(True)
