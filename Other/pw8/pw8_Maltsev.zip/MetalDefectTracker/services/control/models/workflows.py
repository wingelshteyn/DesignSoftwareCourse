from dataclasses import dataclass
import sys
from pathlib import Path

SHARED_CONTRACTS_ROOT = Path(__file__).resolve().parents[3] / "shared-contracts" / "python"
if str(SHARED_CONTRACTS_ROOT) not in sys.path:
    sys.path.append(str(SHARED_CONTRACTS_ROOT))

from mdt_shared_contracts.contracts import DetectionRequest, ProcessingConfiguration, ReceivedImage


@dataclass(slots=True)
class DetectionWorkflow:
    """
    Prepares local detection requests from the data already gathered
    by the Receiver service and configuration supplied by the
    Administration service.
    """

    processing_configuration: ProcessingConfiguration

    def prepare_detection_request(self, received_image: ReceivedImage) -> DetectionRequest:
        return DetectionRequest(
            image_path=received_image.image_path,
            resolution=received_image.resolution,
            threshold=self.processing_configuration.detection_threshold,
        )
