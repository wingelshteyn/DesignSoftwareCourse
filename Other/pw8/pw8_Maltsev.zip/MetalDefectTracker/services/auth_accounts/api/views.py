from django.http import JsonResponse


def health(request):
    return JsonResponse({"service": "auth_accounts", "status": "ok"})
