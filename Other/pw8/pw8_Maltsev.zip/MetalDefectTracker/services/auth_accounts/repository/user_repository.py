class UserRepository:
    """
    Placeholder repository for future persistence of users, credentials, and role assignments.
    """

    def list_users(self) -> list[dict[str, object]]:
        return []
