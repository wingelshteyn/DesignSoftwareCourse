from models.rbac import RBACPolicy


def build_default_rbac_policy() -> RBACPolicy:
    return RBACPolicy()
