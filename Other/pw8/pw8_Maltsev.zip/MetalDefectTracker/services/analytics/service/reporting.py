from dataclasses import dataclass
import sys
from pathlib import Path

SHARED_CONTRACTS_ROOT = Path(__file__).resolve().parents[3] / "shared-contracts" / "python"
if str(SHARED_CONTRACTS_ROOT) not in sys.path:
    sys.path.append(str(SHARED_CONTRACTS_ROOT))

from mdt_shared_contracts.contracts import AnalyticsSummary, ReceivedImage


@dataclass(slots=True)
class AnalyticsReportService:
    """
    Read-oriented analytics service. In the restructured architecture
    it consumes already prepared data rather than importing domain classes
    from other services directly.
    """

    def build_summary(
        self,
        role: str,
        received_image: ReceivedImage,
        verification_available: bool,
    ) -> AnalyticsSummary:
        if role not in {"technologist", "administrator"}:
            raise PermissionError("Analytics access denied.")

        return AnalyticsSummary(
            received_resolution=received_image.resolution,
            verification_available=verification_available,
            requested_by=role,
        )
