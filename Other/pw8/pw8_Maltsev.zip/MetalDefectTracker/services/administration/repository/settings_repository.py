class SettingsRepository:
    """
    Placeholder repository for camera and processing configuration persistence.
    """

    def get_active_configuration(self) -> dict[str, object]:
        return {}
