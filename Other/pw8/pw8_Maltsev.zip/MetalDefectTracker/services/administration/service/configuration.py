import sys
from pathlib import Path

SHARED_CONTRACTS_ROOT = Path(__file__).resolve().parents[3] / "shared-contracts" / "python"
if str(SHARED_CONTRACTS_ROOT) not in sys.path:
    sys.path.append(str(SHARED_CONTRACTS_ROOT))

from mdt_shared_contracts.contracts import CameraConfiguration, ProcessingConfiguration
from models.policy import AdministrationPolicy


def export_camera_configuration(policy: AdministrationPolicy) -> CameraConfiguration:
    return CameraConfiguration(
        resolution=policy.camera_resolution,
        capture_interval_seconds=policy.capture_interval_seconds,
    )


def export_processing_configuration(policy: AdministrationPolicy) -> ProcessingConfiguration:
    return ProcessingConfiguration(
        detection_threshold=policy.detection_threshold,
        manual_verification_enabled=policy.manual_verification_enabled,
    )
