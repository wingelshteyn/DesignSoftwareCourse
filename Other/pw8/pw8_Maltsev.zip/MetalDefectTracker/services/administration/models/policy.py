from dataclasses import dataclass


@dataclass(slots=True)
class AdministrationPolicy:
    """
    Administrative settings exposed by the Administration service.
    In the service-based architecture access checks are delegated to the
    Auth & Accounts service at the API boundary, so the domain object no longer
    imports access-control classes directly.
    """

    camera_resolution: str = "1920x1080"
    capture_interval_seconds: int = 5
    detection_threshold: float = 0.5
    manual_verification_enabled: bool = True

    def can_manage_configuration(self, role: str) -> bool:
        return role == "administrator"
