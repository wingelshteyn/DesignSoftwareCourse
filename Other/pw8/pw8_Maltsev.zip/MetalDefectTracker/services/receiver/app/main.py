from fastapi import FastAPI


app = FastAPI(title="Receiver Service")


@app.get("/health")
async def health() -> dict[str, str]:
    return {"service": "receiver", "status": "ok"}


@app.post("/images")
async def ingest_image() -> dict[str, str]:
    return {"status": "accepted", "message": "Image ingestion placeholder"}
