from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class CameraRegistration:
    image_path: str
    source: str = "camera"
