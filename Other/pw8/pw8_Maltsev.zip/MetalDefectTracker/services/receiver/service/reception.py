from dataclasses import dataclass
import sys
from pathlib import Path

SHARED_CONTRACTS_ROOT = Path(__file__).resolve().parents[3] / "shared-contracts" / "python"
if str(SHARED_CONTRACTS_ROOT) not in sys.path:
    sys.path.append(str(SHARED_CONTRACTS_ROOT))

from mdt_shared_contracts.contracts import CameraConfiguration, ReceivedImage


@dataclass(slots=True)
class ImageReceptionService:
    """
    Receives image metadata and uses camera configuration fetched from
    the Administration service through API calls.
    """

    camera_configuration: CameraConfiguration

    def receive(self, image_path: str) -> ReceivedImage:
        return ReceivedImage(
            image_path=image_path,
            resolution=self.camera_configuration.resolution,
            capture_interval_seconds=self.camera_configuration.capture_interval_seconds,
        )
