class ImageRepository:
    """
    Placeholder repository for metadata and object-storage references.
    """

    def save_reference(self, image_path: str) -> dict[str, str]:
        return {"image_path": image_path}
