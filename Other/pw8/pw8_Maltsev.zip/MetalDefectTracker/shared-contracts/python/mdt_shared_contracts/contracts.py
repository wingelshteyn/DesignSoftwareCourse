from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class CameraConfiguration:
    resolution: str = "1920x1080"
    capture_interval_seconds: int = 5


@dataclass(frozen=True, slots=True)
class ProcessingConfiguration:
    detection_threshold: float = 0.5
    manual_verification_enabled: bool = True


@dataclass(frozen=True, slots=True)
class ReceivedImage:
    image_path: str
    resolution: str
    capture_interval_seconds: int


@dataclass(frozen=True, slots=True)
class DetectionRequest:
    image_path: str
    resolution: str
    threshold: float


@dataclass(frozen=True, slots=True)
class VerificationAvailability:
    allowed: bool
    reason: str | None = None


@dataclass(frozen=True, slots=True)
class AnalyticsSummary:
    received_resolution: str
    verification_available: bool
    requested_by: str


@dataclass(frozen=True, slots=True)
class DetectionTask:
    control_record_id: int
    image_path: str
    threshold: float
