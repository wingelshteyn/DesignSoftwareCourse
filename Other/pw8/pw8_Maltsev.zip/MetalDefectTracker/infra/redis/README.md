Redis is used as a cache layer for frequently requested data.
